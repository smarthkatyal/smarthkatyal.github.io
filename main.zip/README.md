# Emission Analysis using Data Visualization

This project is submitted as part of CS7CS4- Data Visualization at Trinity College Dublin by **Smarth Katyal** as part of **Assignment 4**


# Steps to Execute
1. Download the zip file named "main.zip" and unzip it using WinZip or WinRar.
2. Go inside the unzipped folder
3. Locate the file "index.html" and open it in "Google Chrome" web browser.

